NEXA NEWS — COMPLETE NEWS WEBSITE UPDATE

Included: news homepage, Search with local search history, Explore, Trending, About, responsive iOS-inspired navigation, white/blue theme, moving short blue card-edge glow, and keyless public RSS news API.

COPY TO YOUR EXISTING NEXT.JS APP
1. Extract this ZIP.
2. Open the nexa-bottom-nav-fixed folder.
3. Upload/replace its app and components folders in your existing GitHub repository, keeping the same folder paths.
4. KEEP your existing package.json, next.config.* and any unrelated API routes/secrets. No new npm package is required for the news feed.
5. Commit and push; Vercel will redeploy.

News API: GET /api/news?mode=home, /api/news?mode=explore, /api/news?mode=trending, /api/news?mode=search&q=keyword. It reads public RSS feeds from BBC News, Al Jazeera and NPR without API keys. The API may return fewer stories if a feed blocks or is temporarily unavailable.

Search history is stored only in the visitor's browser localStorage. Trending order is a recency/source-weight estimate, not real engagement analytics. Each headline opens the publisher's original article.

Routes: /, /search, /explore, /trending, /about. Legacy /dashboard and /overview files are retained in this package but are no longer part of the main navigation.

Brand/favicon: the existing WEB_LOGO environment variable is preserved.
